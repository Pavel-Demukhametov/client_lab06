import React, { useState } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import Graph from "./Graph";

const App = () => {
  const [selectedNode, setSelectedNode] = useState(null);

  return (
    <div style={{ width: "100vw", height: "100vh", overflow: "hidden" }}>
      <Canvas camera={{ position: [0, 0, 100], fov: 75 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <Graph onNodeSelect={setSelectedNode} />
        <OrbitControls />
      </Canvas>
      
      {selectedNode && (
        <div
          style={{
            position: "absolute",
            top: "10px",
            left: "10px",
            background: "rgba(0, 0, 0, 0.7)",
            color: "white",
            padding: "10px",
            borderRadius: "5px",
            maxWidth: "300px",
            zIndex: 1000,
          }}
        >
          <h3>Информация о Узле</h3>
          <p>
            <strong>ID:</strong> {selectedNode.id}
          </p>
          <p>
            <strong>Label:</strong> {selectedNode.label}
          </p>
          <h4>Связи:</h4>
          {selectedNode.relationships && selectedNode.relationships.length > 0 ? (
            <ul>
              {selectedNode.relationships.map((rel, index) => (
                <li key={index}>
                  <strong>Тип:</strong> {rel.relationship} <br />
                  <strong>Целевой ID:</strong> {rel.related_node?.id || "N/A"}
                </li>
              ))}
            </ul>
          ) : (
            <p>Связи не найдены</p>
          )}
        </div>
      )}
    </div>
  );
};

export default App;