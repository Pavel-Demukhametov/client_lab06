import React, { useEffect, useState } from "react";
import { Sphere, Line } from "@react-three/drei";
import { fetchNodes, fetchNodeWithRelationships } from "./api";

const Graph = ({ onNodeSelect }) => {
  const [nodes, setNodes] = useState([]);
  const [links, setLinks] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      const nodesData = await fetchNodes();
      const uniqueNodes = Array.from(
        new Map(
          nodesData
            .filter((node) => node.id !== null)
            .map((node) => [node.id, node])
        ).values()
      );
      setNodes(
        uniqueNodes.map((node) => ({
          id: node.id,
          label: node.label[0],
          position: [
            Math.random() * 100 - 50,
            Math.random() * 100 - 50,
            Math.random() * 100 - 50,
          ],
          color: node.label[0] === "User" ? "blue" : "green",
        }))
      );
    };
    loadData();
  }, []);

  const handleNodeClick = async (node) => {
    try {
      const relationships = await fetchNodeWithRelationships(node.id);
      onNodeSelect({
        ...node,
        relationships,
      });

      const newLinks = relationships.map((rel) => ({
        source: node.id,
        target: rel.related_node?.id,
      }));
      setLinks(newLinks);
    } catch (error) {
      console.error("Ошибка при загрузке связей узла:", error);
    }
  };

  return (
    <>
      {nodes.map((node) => (
        <Sphere
          key={node.id}
          args={[0.5, 32, 32]}
          position={node.position}
          onClick={() => handleNodeClick(node)}
        >
          <meshStandardMaterial color={node.color} />
        </Sphere>
      ))}
      {links.map((link, index) => {
        const sourceNode = nodes.find((n) => n.id === link.source);
        const targetNode = nodes.find((n) => n.id === link.target);

        if (!sourceNode || !targetNode) return null;

        return (
          <Line
            key={index}
            points={[sourceNode.position, targetNode.position]}
            color="white"
            lineWidth={1}
          />
        );
      })}
    </>
  );
};

export default Graph;